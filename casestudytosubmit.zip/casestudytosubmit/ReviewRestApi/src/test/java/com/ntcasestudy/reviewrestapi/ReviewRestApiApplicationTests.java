package com.ntcasestudy.reviewrestapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReviewRestApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
