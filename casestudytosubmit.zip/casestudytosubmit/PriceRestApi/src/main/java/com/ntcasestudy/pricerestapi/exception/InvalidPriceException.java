package com.ntcasestudy.pricerestapi.exception;

public class InvalidPriceException extends Exception {
	public InvalidPriceException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}
}
