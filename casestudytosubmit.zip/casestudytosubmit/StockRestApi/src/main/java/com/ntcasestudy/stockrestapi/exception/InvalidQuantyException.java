package com.ntcasestudy.stockrestapi.exception;

public class InvalidQuantyException extends Exception {
	public InvalidQuantyException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}
}
